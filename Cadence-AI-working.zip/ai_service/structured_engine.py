from __future__ import annotations

import json
from datetime import datetime

from fastapi import HTTPException
from pydantic import BaseModel, ValidationError

from .gemini_client import generate_content
from .schemas import RunningOrder


CADENCE_SYSTEM_PROMPT = """You are Cadence Engine, a deterministic event management system.

STRICT RULES:
1. Output valid JSON only.
2. No markdown, no code fences, no preamble.
3. Follow the requested schema exactly.
4. If information is missing, infer a safe operational value and list the assumption in warnings.
"""


def call_gemini_json(
    prompt: str,
    response_model: type[BaseModel] | None = None,
    max_retries: int = 2,
    model: str = "gemini-1.5-flash",
) -> tuple[dict, int]:
    last_error = ""
    full_prompt = f"{CADENCE_SYSTEM_PROMPT}\n\n{prompt}"

    for attempt in range(max_retries + 1):
        raw = ""
        try:
            raw = generate_content(model, full_prompt).strip()
            if raw.startswith("```"):
                raw = "\n".join(
                    line for line in raw.splitlines()
                    if not line.strip().startswith("```")
                ).strip()

            parsed = json.loads(raw)
            if response_model is not None:
                response_model.model_validate(parsed)
            return parsed, attempt
        except (json.JSONDecodeError, ValidationError, HTTPException) as error:
            last_error = f"{type(error).__name__}: {error}"
            full_prompt = (
                f"{CADENCE_SYSTEM_PROMPT}\n\n"
                f"The previous response was invalid: {last_error}\n"
                f"Return corrected JSON only.\n\n{prompt}"
            )

    raise HTTPException(
        status_code=502,
        detail=f"Gemini failed to return valid JSON. Last error: {last_error}",
    )


def build_protocol_running_order_prompt(protocol_text: str) -> str:
    schema = """
{
  "event_id": "string",
  "event_name": "string",
  "generated_at": "ISO 8601 datetime string",
  "total_duration_minutes": 0,
  "items": [
    {
      "sequence": 1,
      "item_id": "item_001",
      "title": "string",
      "type": "session|break|keynote|panel|ceremony|networking|other",
      "start_time": "HH:MM",
      "end_time": "HH:MM",
      "duration_minutes": 0,
      "speaker_id": null,
      "speaker_name": null,
      "location": null,
      "notes": null,
      "status": "scheduled"
    }
  ],
  "warnings": ["string"]
}
"""
    return f"""TASK: Extract a professional event running order from protocol document text.

REQUIREMENTS:
- Keep sequence numbers contiguous starting at 1.
- Use HH:MM 24-hour start_time and end_time.
- duration_minutes must always be an integer.
- Use only these type values: session, break, keynote, panel, ceremony, networking, other.
- Map performance, arrival, opening, prayer, address, meal, photo, and departure into the closest allowed type.
- If timing is incomplete, infer a realistic schedule and put the assumption in warnings.
- generated_at must be {datetime.utcnow().isoformat()}.

OUTPUT SCHEMA:
{schema}

PROTOCOL DOCUMENT TEXT:
{protocol_text}
"""


def generate_running_order_from_protocol(protocol_text: str) -> tuple[RunningOrder, int]:
    raw, retries = call_gemini_json(
        build_protocol_running_order_prompt(protocol_text),
        response_model=RunningOrder,
    )
    return RunningOrder.model_validate(raw), retries


def running_order_to_frontend_rows(order: RunningOrder) -> list[dict]:
    rows = []
    for item in order.items:
        rows.append({
            "time": f"{item.start_time}-{item.end_time}",
            "dur": f"{item.duration_minutes}m",
            "activity": item.title,
            "loc": item.location or "",
            "role": item.speaker_name or item.notes or "",
            "status": "pending" if item.status == "scheduled" else item.status,
        })
    return rows
