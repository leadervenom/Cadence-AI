class AIController {

    getStatus(req,res){

        res.json({

            module:"Gemini AI Engine",

            status:"ACTIVE",

            provider:"gemini",

            serviceUrl: process.env.GEMINI_SERVICE_URL || "http://localhost:8000"

        });

    }


    async chat(req, res, next) {

        try {

            const serviceUrl = process.env.GEMINI_SERVICE_URL || "http://localhost:8000";

            const response = await fetch(`${serviceUrl}/chat`, {

                method: "POST",

                headers: {

                    "Content-Type": "application/json"

                },

                body: JSON.stringify(req.body || {})

            });


            const data = await response.json().catch(() => ({}));

            if (!response.ok) {

                res.status(response.status).json({

                    error: data.detail || data.error || "Gemini service request failed"

                });

                return;

            }

            res.json(data);

        } catch (error) {

            if (error.cause?.code === "ECONNREFUSED") {

                res.status(503).json({

                    error: "Gemini FastAPI service is not running. Start it with npm run ai."

                });

                return;

            }

            next(error);

        }

    }


    async parseProtocol(req, res, next) {

        this.forwardToGeminiService("/protocol/parse", req, res, next);

    }


    async generateProtocolRunningOrder(req, res, next) {

        this.forwardToGeminiService("/protocol/running-order", req, res, next);

    }


    async forwardToGeminiService(path, req, res, next) {

        try {

            const serviceUrl = process.env.GEMINI_SERVICE_URL || "http://localhost:8000";

            const response = await fetch(`${serviceUrl}${path}`, {

                method: "POST",

                headers: {

                    "Content-Type": "application/json"

                },

                body: JSON.stringify(req.body || {})

            });


            const data = await response.json().catch(() => ({}));

            if (!response.ok) {

                res.status(response.status).json({

                    error: data.detail || data.error || "Gemini service request failed"

                });

                return;

            }

            res.json(data);

        } catch (error) {

            if (error.cause?.code === "ECONNREFUSED") {

                res.status(503).json({

                    error: "Gemini FastAPI service is not running. Start it with npm run ai."

                });

                return;

            }

            next(error);

        }

    }

}

export default AIController;
